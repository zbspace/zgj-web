<template>
  <Layout>
    <router-view />
  </Layout>
</template>

<script setup>
import Layout from "@/layouts/main";
</script>

<style lang="scss" scoped>

</style>
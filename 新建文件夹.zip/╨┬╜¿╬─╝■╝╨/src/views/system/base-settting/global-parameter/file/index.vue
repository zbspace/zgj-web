<template>
  <div>
    file
  </div>
</template>

<script setup>
import { reactive } from "vue"
const obj = reactive({ a: 1 })
</script>

<style lang="scss" scoped>

</style>

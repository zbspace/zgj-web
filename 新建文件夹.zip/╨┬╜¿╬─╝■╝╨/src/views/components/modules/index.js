
import KDialog from './kdialog.vue'
export default function install(app){
    app.component("KDialog", KDialog)
}
